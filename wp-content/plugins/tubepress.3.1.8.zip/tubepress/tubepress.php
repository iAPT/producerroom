<?php
/**
Plugin Name: TubePress
Plugin URI: http://tubepress.com
Description: Displays gorgeous YouTube and Vimeo galleries in your posts, pages, and/or sidebar. Upgrade to <a href="http://tubepress.com/pro/">TubePress Pro</a> for more features!
Author: TubePress LLC
Version: 3.1.8
Author URI: http://tubepress.com

Copyright 2006 - 2014 TubePress LLC (http://tubepress.com)

This file is part of TubePress (http://tubepress.com)

This Source Code Form is subject to the terms of the Mozilla Public
License, v. 2.0. If a copy of the MPL was not distributed with this
file, You can obtain one at http://mozilla.org/MPL/2.0/.
*/

include 'src/main/php/scripts/boot.php';
